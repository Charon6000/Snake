using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SnakeMovement : MonoBehaviour
{
    public GameObject dupka;
    public List<GameObject> dupki;
    public float speed;
    Vector2 dir = Vector2.up;
    float makeslower;
    public float slow;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        makeslower = slow;
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        Rotate();

        foreach (var item in dupki)
                item.GetComponent<DupkaAI>().naturaldir = dir;
    }

    void Move()
    {
        rb.velocity = dir * speed;
    }

    void Rotate()
    {
        if(Input.GetButtonDown("Right") && dir != Vector2.left)
        {
            transform.rotation = Quaternion.Euler(0,0,-90);
            dir = Vector2.right;
        }
        if(Input.GetButtonDown("Left") && dir != Vector2.right)
        {
            transform.rotation = Quaternion.Euler(0,0,90);
            dir = Vector2.left;
        }
        if(Input.GetButtonDown("Up") && dir != Vector2.down)
        {
            transform.rotation = Quaternion.Euler(0,0,0);
            dir = Vector2.up;
        }
        if(Input.GetButtonDown("Down") && dir != Vector2.up)
        {
            transform.rotation = Quaternion.Euler(0,0,180);
            dir = Vector2.down;
        }
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.tag == "Japko")
        {
            GameObject dupa = Instantiate(dupka, transform.position, transform.rotation);
            dupa.GetComponent<DupkaAI>().speed = speed;
            dupa.GetComponent<DupkaAI>().dir = dir;
            dupa.GetComponent<DupkaAI>().naturaldir = dir;
            dupa.GetComponent<DupkaAI>().slow = slow;
            dupki.Add(dupa);
            slow += makeslower;
        }

        if(other.tag == "dupka" && other.gameObject != dupki[0] && other.gameObject != dupki[1] && other.gameObject != dupki[2])
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);

        if(other.tag == "coll")
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
