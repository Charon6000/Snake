using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject coll;
    public Text text;
    public static int licznik = 0;
    public GameObject japko;
    public GameObject snake;
    public GameObject tlo;
    public int size;
    
    // Start is called before the first frame update
    void Start()
    {
        tlo.transform.localScale = new Vector3(size,size,0);
        Instantiate(coll, new Vector3(size/2,0,0), Quaternion.identity);
        Instantiate(coll, new Vector3(-size/2,0,0), Quaternion.identity);
        Instantiate(coll, new Vector3(0,size/2,0), Quaternion.Euler(0,0,90));
        Instantiate(coll, new Vector3(0,-size/2,0), Quaternion.Euler(0,0,90));
        Camera.main.GetComponent<Camera>().orthographicSize = size/2;
        Invoke("SpawnSnake", 3f);
    }

    // Update is called once per frame
    void Update()
    {
        Spawnjapko();
        text.text = licznik.ToString();
    }

    void Spawnjapko()
    {
        if(!GameObject.FindGameObjectWithTag("Japko"))
        {
            Instantiate(japko, new Vector2(Random.Range(-size/2 + 1,size/2 - 1),Random.Range(-size/2+1,size/2-1)), Quaternion.identity);
        }
    }

    void SpawnSnake()
    {
        Instantiate(snake, new Vector2(0,0), Quaternion.identity);
    }
    
}
