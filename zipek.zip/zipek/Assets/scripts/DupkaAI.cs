using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DupkaAI : MonoBehaviour
{
    public float speed;
    public float slow;
    Rigidbody2D rb;
    public Vector2 naturaldir;
    public Vector2 dir;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Invoke("TurnCollder", GameObject.FindGameObjectWithTag("Player").GetComponent<SnakeMovement>().slow);
    }

    void TurnCollder()
    {
        GetComponent<BoxCollider2D>().enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        Invoke("Move", slow);
        if(Input.GetButtonDown("Right") && naturaldir != Vector2.left)
        {
            Invoke("RotateR", slow);
        }
        if(Input.GetButtonDown("Left") && naturaldir != Vector2.right)
        {
            Invoke("RotateL", slow);
        }
        if(Input.GetButtonDown("Up") && naturaldir != Vector2.down)
        {
            Invoke("RotateU", slow);
        }
        if(Input.GetButtonDown("Down") && naturaldir != Vector2.up)
        {
            Invoke("RotateD", slow);
        }
    }

    void Move()
    {
        rb.velocity = dir * speed;
    }

    void RotateL()
    {
        transform.rotation = Quaternion.Euler(0,0,90);
        dir = Vector2.left;
    }

    void RotateR()
    {
        transform.rotation = Quaternion.Euler(0,0,-90);
        dir = Vector2.right;
    }

    void RotateD()
    {
        transform.rotation = Quaternion.Euler(0,0,180);
        dir = Vector2.down;
    }

    void RotateU()
    {
        transform.rotation = Quaternion.Euler(0,0,0);
        dir = Vector2.up;
    }
}
